// Title: Student Details
// Author: Genesisbyte
// Date: 05/03/2024
// Description: Using OOP to ask for store and display user input

// Importing the libraries
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

// Creating a class to create variables and assign them to this
public class Student {
    private String name;
    private String age;
    private String address;
    private String number;

    private List<String>list=new ArrayList<String>();
    Scanner scanner =new Scanner(System.in);
    public Student(String name,String age,String address,String number){
        this.name=name;
        this.age=age;
        this.address=address;
        this.number=number;

    }
    // Creating the method to ask for user input
    public void Input() {
        try {
            while (true) {
                System.out.println("Enter name or q to quit: ");
                name = scanner.nextLine();
                if (name.equalsIgnoreCase("q")){
                    break;
                }
                System.out.println("Enter age: ");
                age = scanner.nextLine();
                System.out.println("Enter address: ");
                address = scanner.nextLine();
                System.out.println("Enter student number: ");
                number = scanner.nextLine();
                list.add(name);
                list.add(age);
                list.add(address);
                list.add(number);
            }
            // If user enters wrong input:
        } catch (InputMismatchException e) {
            System.out.println("Invalid Input!");
        }
    }
    // Display the list of students
    public void Display(){
        System.out.println(list);
    }

public static void main(String[] args) {
        // Creating the instances of the object
        Student student = new Student("","","","");
        student.Input();
        student.Display();

    }
}