// Title: Rock Paper Scissors
// Author: Genesisbyte
// Date: 05/Mar/24
// Description: Using OOP to create a rock,paper,scissors game

// Importing the libraries
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

// Creating class to store variables
public class Game {
    Scanner scanner = new Scanner(System.in);
    Random rand = new Random();
    private int cpuScore;
    private int userScore;
    private int userInput;
    private int cpuChoice;

    // Assigning variables
    public Game(int userInput,int cpuScore,int userScore,int cpuChoice){
        this.cpuScore=cpuScore;
        this.userScore=userScore;
        this.userInput=userInput;
        this.cpuChoice=cpuChoice;
    }
    // Creating method to display menu
    public void Menu(){
        System.out.println("Rock Paper Scissors");
        System.out.println("********************");
        System.out.println("1/ Rock");
        System.out.println("2/ Paper");
        System.out.println("3/ Scissors");
    }
    // Creating method to play the game
    public void Play(){
        try{
            while (cpuScore!=5 && userScore!=5){
                System.out.printf("Player Score:%d",userScore);
                System.out.printf("CPU Score:%d",cpuScore);
                System.out.println("\nEnter 1 for rock,2 for scissors,3 for paper ");
                cpuChoice= rand.nextInt(0,3);
                userInput=scanner.nextInt();
                if (cpuChoice==0){
                    System.out.println("CPU Selects:Rock");
                    switch (userInput){
                        case 1:
                            System.out.println("Tie");
                            break;
                        case 2:
                            System.out.println("You win!");
                            userScore++;
                            break;
                        case 3:
                            System.out.println("CPU wins!");
                            cpuScore++;
                            break;

                    }

                }
                else if (cpuChoice==1){
                    System.out.println("CPU Selects:Paper");
                    switch (userInput){
                        case 1:
                            System.out.println("CPU wins!");
                            cpuScore++;
                            break;
                        case 2:
                            System.out.println("Draw!");
                            break;
                        case 3:
                            System.out.println("You win!");
                            userScore++;
                            break;

                    }
                }
                else if (cpuChoice==2){
                    System.out.println("CPU SELECTS:Scissors");
                    switch (userInput){
                        case 1:
                            System.out.println("You win!");
                            userScore++;
                            break;
                        case 2:
                            System.out.println("CPU wins!");
                            cpuScore++;
                            break;
                        case 3:
                            System.out.println("Draw!");
                            break;

                    }
                }
            }
        }catch (InputMismatchException e){
            System.out.println("Invalid Input!");
        }

    }
    // Method to print calculation
    public void Calculation(){
        if (cpuScore==5){
            System.out.println("CPU WIN!");
        }
        else {
            System.out.println("YOU WIN!");
        }
    }


    public static void main(String[] args) {
        // Creating instances of objects and calling appropriate function
            Game newGame = new Game(0,0,0,0);
            newGame.Menu();
            newGame.Play();
            newGame.Calculation();


    }
}